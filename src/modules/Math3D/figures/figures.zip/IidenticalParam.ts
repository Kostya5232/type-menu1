export interface IidenticalParam {
    color: string;
    x: number;
    y: number;
    z: number;
}